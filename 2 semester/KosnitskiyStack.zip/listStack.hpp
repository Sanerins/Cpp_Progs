#ifndef INC_3_1_STACK_LISTSTACK_HPP
#define INC_3_1_STACK_LISTSTACK_HPP

#include "stack.hpp"
#include "Exceptions.hpp"

template<class T>
class StackList: public Stack<T>
{
public:

  StackList(const T& item)
  {
    tail_ = new Node(item);
  }

  ~StackList()
  {
    Node* temp;
    while (tail_ != nullptr)
    {
      temp = tail_->prev_;
      delete tail_;
      tail_ = temp;
    }
  }

  void push(const T& src) override
  {
    if(tail_ != nullptr)
    {
      tail_->next_ = new Node(src);
      tail_->next_->prev_ = tail_;
      tail_ = tail_->next_;
    }
    else
    {
      tail_ = new Node(src);
    }
  }

  T pop() override
  {
    if (isEmpty())
    {
      throw StackUnderflow("This stack is empty already. There is nothing to pop from it");
    }
    T temp = tail_->item_;
    if(tail_->prev_ == nullptr)
    {
      delete tail_;
      tail_ = nullptr;
    }
    else
    {
      tail_ = tail_->prev_;
      delete tail_->next_;
    }
    return temp;
  }

  const T& peek() override
  {
    if (isEmpty())
    {
      throw StackUnderflow("This stack is empty.");
    }
    return tail_->item_;
  }

  bool isEmpty() override
  {
    return (tail_ == nullptr);
  }

private:
  struct Node
  {
    Node(const T& item)
    {
      next_ = nullptr;
      prev_ = nullptr;
      item_ = item;
    }
    ~Node()
    {
      next_ = nullptr;
      prev_ = nullptr;
      item_ = 0;
    }
    Node* next_;
    Node* prev_;
    T item_;
  };
  Node* tail_;
};

#endif //INC_3_1_STACK_LISTSTACK_HPP
