#ifndef INC_3_1_STACK_EXCEPTIONS_HPP
#define INC_3_1_STACK_EXCEPTIONS_HPP

#include <exception>
#include <cstring>

struct StackOverflow : public std::exception
{
  StackOverflow(const char* text)
  {
    what = text;
  }

  std::string what;
};

struct StackUnderflow : public std::exception
{
  StackUnderflow(const char* text)
  {
    what = text;
  }
  std::string what;
};

struct WrongStackSize : public std::exception
{
  WrongStackSize(const char* text)
  {
    what = text;
  }

  std::string what;
};

#endif //INC_3_1_STACK_EXCEPTIONS_HPP
