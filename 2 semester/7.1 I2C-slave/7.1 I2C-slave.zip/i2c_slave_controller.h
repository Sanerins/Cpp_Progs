#ifndef INC_7_1_I2C_SLAVE_I2C_SLAVE_CONTROLLER_H
#define INC_7_1_I2C_SLAVE_I2C_SLAVE_CONTROLLER_H

#include <systemc.h>

SC_MODULE(I2CSlaveController)
{
  /*** INPUT SIGNALS: ***/
  sc_in<bool> scl;
  sc_in<bool> sda;
  /*** OUTPUT SIGNALS: ***/
  sc_out<sc_uint<8> > data;
  sc_out<bool> valid;
  sc_out<bool> sda_m;
  sc_out<bool> sda_o;
  /*** INTERNAL SIGNALS: ***/
  sc_signal<sc_uint<4> > count;
  sc_signal<sc_uint<8>> out;
  sc_signal<bool> next_scl;
  sc_signal<bool> validation;
  sc_signal<bool> release_data;
  sc_signal<bool> release_data_old;
  // methods
  void comb_logic();
  void seq_logic_0();
  void seq_logic_1();
  void seq_logic_01();
  void seq_logic_2();
  // constructor of module
  SC_CTOR(I2CSlaveController)
  {
    SC_METHOD(seq_logic_0);
    sensitive << scl.pos();
    SC_METHOD(seq_logic_1);
    sensitive << scl.neg();
    SC_METHOD(seq_logic_01);
    sensitive << scl;
    SC_METHOD(seq_logic_2);
    sensitive << sda.pos();
    SC_METHOD(comb_logic);
    // чувствительность к next_scl вместо самого scl, чтобы в последовательной логике
    // успели измениться сигналы
    sensitive << next_scl << release_data;
  }
};

#endif //INC_7_1_I2C_SLAVE_I2C_SLAVE_CONTROLLER_H
