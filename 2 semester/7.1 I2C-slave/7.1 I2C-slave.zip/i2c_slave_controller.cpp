#include "i2c_slave_controller.h"

void I2CSlaveController::seq_logic_0()// фронт scl
{
  if (count.read() == 11) {
    // комб. логика не сработает лишний раз, зато увидит, что надо вывести байт
    release_data_old.write(!release_data.read());
    count.write(2);// переходим к ожиданию сигнала начала передачи байта
  } else {
    if (count.read() == 2) {// если передается первый бит,
      // зададим соответствующее стартовое значение сигналу
      if (sda.read()) {
        out.write(128);
      }
      else {
        out.write(0);
      }
    }
    else {
      // запись в соответствующий бит значения с sda
      if (sda.read()) {
        out.write(out.read() + (1 << (9 - count.read())));
      }
    }
    // «смотрим» на следующий бит
    count.write(count.read() + 1);
  }
}
void I2CSlaveController::seq_logic_1()// спад scl
{
  if (count.read() == 10) {
    // если все биты записаны, выдаем подтверждение
    validation.write(1);
  } else {
    validation.write(0);
  }
}
void I2CSlaveController::seq_logic_01()// изменение scl
{
  // меняем next_scl
  next_scl.write(!scl.read());
}
void I2CSlaveController::seq_logic_2()//фронт sda
{
  if (count.read() == 2) {
    // сработает если надо завершить вывод принятого байта
    release_data.write(release_data_old.read());
    // сработает комб. логика и выключит вывод принятого байта
  }
}
void I2CSlaveController::comb_logic()
{
  if (scl.read()) {// если на scl был фронт
    // выводим байт если надо
    if ((release_data.read()!=release_data_old.read())) {
      data.write(out);
      valid.write(true);
    }
    else {
      // в случае необходимости заканчиваем вывод байта
      if (count.read() <3) {
        data.write('Z');
        valid.write(false);
      }
    }
  }
  else {// если же на scl был спад
    // подтверждаем прием если надо
    if (validation.read()) {
      sda_m.write(true);
      sda_o.write(false);
    }
    else {
      sda_m.write(false);
      sda_o.write('Z');
    }
  }
}
